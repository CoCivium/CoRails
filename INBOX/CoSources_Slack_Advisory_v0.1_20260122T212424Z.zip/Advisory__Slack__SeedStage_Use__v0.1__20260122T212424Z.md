# CoSources → CoPrime Advisory: Slack availability + seed-stage usage (v0.1)

**UTC:** 20260122T212424Z  
**Session label:** CoSources  
**Purpose:** Inform CoPrime that Slack exists, propose seed-safe uses now, and capture MasterPlan items for later.

## Status (as reported by rick)
- Two Slack identities exist:
  - rballard@InSeed.com
  - CoCivium@CoCivium.org
- The CoCivium Slack is integrated with the CoCivium GitHub account via a Slack GitHub app (API-backed).

## Recommendation: Slack posture in seed
Treat Slack as a **notification + lightweight coordination layer**; GitHub remains the **source of truth** (Issues / Discussions / PRs).
This avoids “parallel universe drift” and preserves auditability and consent trails.

## Seed-safe actions to do now (low risk)
1) **Pin two messages in #announcements**
   - “Slack is optional; source of truth is GitHub; post links not long threads.”
   - “No secrets / no personal data / no vuln reports publicly (SECURITY.md process).”
2) **Create a minimal channel taxonomy**
   - #announcements (read mostly)
   - #help (questions that should be redirected to GitHub)
   - #dev (short coordination; still link to GitHub)
   - (Optional) #watchers (for casual intros; still funnel work to GitHub)
3) **Add an intake rule (manual or bot)**
   - If someone posts a question in Slack, reply: “Please open a GitHub Discussion/Issue; drop the link here.”
4) **Enable GitHub event notifications to Slack**
   - PR opened/merged, issue opened/closed, release published.
   - Prefer digesty settings; avoid noisy firehose.

## Things to delay until CoPrime says GO (higher risk / attention-attracting)
- Broad “welcome the world” broadcasts that invite press/random inbound.
- Publishing detailed architecture, timelines, or sensitive strategy.
- Open invites that imply support guarantees.

## MasterPlan items to add (for later hardening / scale)
- **Slack governance doc** (one page): purpose, rules, where decisions live, escalation paths.
- **Security and privacy rules**: no secrets, no personal data, vulnerability reporting route.
- **Bot/automation plan**:
  - auto-reply templates for “please file GitHub issue/discussion”
  - weekly digest summarizing GitHub activity
  - link unfurl / canonical link checks
- **Contributor on-ramp**:
  - pinned “Start Here” (GitHub) + pinned “How to engage” (Slack)
  - “first issues” label flow
- **Ledger / provenance**:
  - decisions are captured on GitHub (ADR/discussion), Slack only references links.

## Optional copy snippets (if needed later)
**Slack pinned (short):**
- “Slack = notifications + coordination. GitHub = truth. If you have a question/idea, open a GitHub Discussion/Issue and link it here. Don’t post secrets or personal data.”

**GitHub pinned (short):**
- “Seed stage; docs churn. Use Discussions for questions/ideas, Issues for actionable work, PRs for changes. Don’t post sensitive info; security via SECURITY.md.”

---
**End condition:** CoPrime acknowledges and decides whether to (a) keep Slack quiet, (b) pin minimal onboarding, (c) add MP items above.
